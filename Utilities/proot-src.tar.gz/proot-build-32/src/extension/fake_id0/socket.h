#ifndef FAKE_ID0_SOCKET_H
#define FAKE_ID0_SOCKET_H

#include "tracee/tracee.h"
#include "extension/fake_id0/config.h"

int handle_socket_exit_end(Tracee *tracee, Config *config);

#endif /* FAKE_ID0_SOCKET_H */
