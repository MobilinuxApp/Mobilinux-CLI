#!/data/data/com.termux/files/usr/bin/bash
### Configure Script for Debian System after Postinstall
### Runs in proot. Essential Bindings only
unset LD_PRELOAD
proot --link2symlink --kill-on-exit --kernel-release="5.1.0-mobilinux" \
 -0 -r $PREFIX/share/debian/rootfs \
 -b /dev \
 -b /proc \
 -b /sys \
 -b $PREFIX/tmp:/dev/shm \
 -b /dev/urandom:/dev/random \
 -w /root \
 /usr/bin/env -i \
 TERM=$TERM \
 USER=root \
 HOME=/root \
 PATH=/usr/local/bin:/usr/local/sbin:/usr/local/games:/usr/bin:/usr/sbin:/usr/games:/bin:/sbin:/opt \
 LANG=C.UTF-8 \
 /opt/debian-config.sh
